import React from 'react'

const Profile = () => {
  return (
    <div>
        <img src="https://images.pexels.com/photos/12796847/pexels-photo-12796847.jpeg?_gl=1*8gowkv*_ga*MTA2Mzg3NzQ3Ni4xNzMzNTAyODQ4*_ga_8JE65Q40S6*czE3NjA1ODgzMzQkbzIkZzEkdDE3NjA1ODgzMzYkajU4JGwwJGgw" height={400} width={300} alt="" srcset="" />
    </div>
  )
}

export default Profile