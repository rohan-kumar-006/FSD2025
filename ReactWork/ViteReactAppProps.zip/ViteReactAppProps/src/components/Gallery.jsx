import React from 'react'
import Profile from './Profile'

const Gallery = () => {
    return (
        <>
            <h2>Profile Image</h2>
            <div className='profiles'>
            <Profile />
            </div>
        </>
    )
}

export default Gallery